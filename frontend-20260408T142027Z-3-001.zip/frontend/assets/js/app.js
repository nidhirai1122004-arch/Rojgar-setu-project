/**
 * RozgarSetu – Shared JS
 * assets/js/app.js
 * API client, auth helpers, toast, UI utilities
 */

// ── Config ────────────────────────────────────────────────────────────────────
const API_BASE = 'http://127.0.0.1:8000/api/v1';

// ── Auth helpers ──────────────────────────────────────────────────────────────
const Auth = {
  getToken   : ()      => localStorage.getItem('rs_token'),
  getRole    : ()      => localStorage.getItem('rs_role'),
  getUserId  : ()      => localStorage.getItem('rs_user_id'),
  isLoggedIn : ()      => !!localStorage.getItem('rs_token'),
  save(token, role, userId) {
    localStorage.setItem('rs_token',   token);
    localStorage.setItem('rs_role',    role);
    localStorage.setItem('rs_user_id', userId);
  },
  clear() {
    ['rs_token','rs_role','rs_user_id'].forEach(k => localStorage.removeItem(k));
  },
};

// ── API fetch wrapper ─────────────────────────────────────────────────────────
async function apiFetch(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const token = Auth.getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });

  if (res.status === 401) {
    Auth.clear();
    window.location.href = '/frontend/pages/auth.html';
    return;
  }

  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Unknown error' }));

    // FastAPI validation error — detail is a list
    if (Array.isArray(err.detail)) {
      const msg = err.detail.map(e => e.msg || JSON.stringify(e)).join(', ');
      throw new Error(msg);
    }

    // detail is an object (shouldn't happen but just in case)
    if (typeof err.detail === 'object' && err.detail !== null) {
      throw new Error(JSON.stringify(err.detail));
    }

    throw new Error(err.detail || err.message || `HTTP ${res.status}`);
  }

  return res.json();
}

const API = {
  get   : (path)         => apiFetch(path),
  post  : (path, body)   => apiFetch(path, { method:'POST',   body: JSON.stringify(body) }),
  put   : (path, body)   => apiFetch(path, { method:'PUT',    body: JSON.stringify(body) }),
  delete: (path)         => apiFetch(path, { method:'DELETE' }),
};

// ── Toast ─────────────────────────────────────────────────────────────────────
function toast(msg, type = 'info', duration = 3500) {
  let wrap = document.getElementById('toast-wrap');
  if (!wrap) {
    wrap = document.createElement('div');
    wrap.id = 'toast-wrap';
    document.body.appendChild(wrap);
  }
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = msg;
  wrap.appendChild(t);
  requestAnimationFrame(() => { requestAnimationFrame(() => t.classList.add('show')); });
  setTimeout(() => {
    t.classList.remove('show');
    setTimeout(() => t.remove(), 350);
  }, duration);
}

// ── Loading overlay ───────────────────────────────────────────────────────────
function showLoader() {
  let el = document.getElementById('rs-loader');
  if (!el) {
    el = document.createElement('div');
    el.id = 'rs-loader';
    el.className = 'loading-overlay';
    el.innerHTML = '<div class="spinner"></div>';
    document.body.appendChild(el);
  }
  el.style.display = 'flex';
}
function hideLoader() {
  const el = document.getElementById('rs-loader');
  if (el) el.style.display = 'none';
}

// ── Modal helpers ─────────────────────────────────────────────────────────────
function openModal(id)  { document.getElementById(id)?.classList.add('open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('open'); }

// ── Tab system ────────────────────────────────────────────────────────────────
function initTabs(containerSelector = '.tabs') {
  document.querySelectorAll(containerSelector + ' .tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.tab;
      const parent = btn.closest('[data-tabs]') || document.body;
      parent.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      parent.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(target)?.classList.add('active');
    });
  });
}

// ── Hamburger nav ─────────────────────────────────────────────────────────────
function initNav() {
  const ham  = document.querySelector('.hamburger');
  const links = document.querySelector('.nav-links');
  if (ham && links) {
    ham.addEventListener('click', () => links.classList.toggle('open'));
  }
  // Highlight active page link
  const currentPage = window.location.pathname.split('/').pop();
  document.querySelectorAll('.nav-link[data-page]').forEach(a => {
    if (a.dataset.page === currentPage) a.classList.add('active');
  });
  // Auth-aware nav
  const authActions = document.getElementById('nav-auth-actions');
  if (authActions) {
    if (Auth.isLoggedIn()) {
      const role = Auth.getRole();
      authActions.innerHTML = `
        <a href="${role === 'worker' ? 'worker_dashboard.html' : 'employer_dashboard.html'}"
           class="nav-link">Dashboard</a>
        <span class="nav-avatar" onclick="logout()" title="Logout">👤</span>`;
    } else {
      authActions.innerHTML = `<a href="auth.html" class="nav-link btn-white">Login / Register</a>`;
    }
  }
}

// ── Logout ────────────────────────────────────────────────────────────────────
function logout() {
  Auth.clear();
  toast('Logged out successfully', 'info');
  setTimeout(() => window.location.href = 'auth.html', 800);
}

// ── Stars renderer ────────────────────────────────────────────────────────────
function renderStars(rating, max = 5) {
  const full  = Math.floor(rating);
  const empty = max - full;
  return '★'.repeat(full) + '☆'.repeat(empty);
}

// ── Relative time ─────────────────────────────────────────────────────────────
function timeAgo(dateStr) {
  const diff = (Date.now() - new Date(dateStr)) / 1000;
  if (diff < 60)     return 'just now';
  if (diff < 3600)   return `${Math.floor(diff/60)}m ago`;
  if (diff < 86400)  return `${Math.floor(diff/3600)}h ago`;
  if (diff < 604800) return `${Math.floor(diff/86400)}d ago`;
  return new Date(dateStr).toLocaleDateString('en-IN');
}

// ── Format currency ───────────────────────────────────────────────────────────
function fmtINR(amount) {
  return `₹${Number(amount).toLocaleString('en-IN')}`;
}

// ── Guards ────────────────────────────────────────────────────────────────────
function requireLogin(redirectTo = 'auth.html') {
  if (!Auth.isLoggedIn()) {
    toast('Please login first', 'error');
    setTimeout(() => window.location.href = redirectTo, 700);
    return false;
  }
  return true;
}
function requireRole(role) {
  if (Auth.getRole() !== role) {
    toast('Access denied', 'error');
    setTimeout(() => window.location.href = 'auth.html', 700);
    return false;
  }
  return true;
}

// ── Auto-init on DOMContentLoaded ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initNav();
  initTabs();
});
