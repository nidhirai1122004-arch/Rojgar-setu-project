"""app/services/trust_score_service.py
Trust score = weighted sum of: ratings, jobs completed, profile completeness, verification
Range: 0 – 100
"""
from sqlalchemy.orm import Session
from app.models.worker import Worker
from app.models.rating import Rating


def calculate_trust_score(worker: Worker, db: Session) -> float:
    score = 0.0

    # 1. Rating average (max 40 pts)
    if worker.total_ratings > 0:
        score += (worker.rating_avg / 5.0) * 40

    # 2. Jobs completed (max 25 pts)
    score += min(worker.jobs_completed * 2.5, 25)

    # 3. Profile completeness (max 20 pts)
    fields = [worker.full_name, worker.age, worker.primary_skill,
              worker.state, worker.district, worker.bio,
              worker.aadhaar_number, worker.profile_photo]
    filled = sum(1 for f in fields if f)
    score += (filled / len(fields)) * 20

    # 4. Aadhaar verified (10 pts)
    if worker.aadhaar_verified:
        score += 10

    # 5. Mobile verified (5 pts)
    if worker.user and worker.user.is_verified:
        score += 5

    return round(min(score, 100), 2)


def update_worker_trust_score(worker_id: int, db: Session):
    worker = db.query(Worker).filter(Worker.id == worker_id).first()
    if worker:
        worker.trust_score = calculate_trust_score(worker, db)
        db.flush()


def add_rating(application_id: int, worker_id: int, employer_id: int,
               rating_val: int, comment: str, given_by_user_id: int,
               db: Session):
    from app.models.rating import Rating
    from app.models.job import JobApplication

    r = Rating(
        application_id=application_id,
        worker_id=worker_id,
        employer_id=employer_id,
        given_by=given_by_user_id,
        rating=rating_val,
        comment=comment,
    )
    db.add(r)
    db.flush()

    # Recalculate worker average
    if worker_id:
        ratings = db.query(Rating).filter(Rating.worker_id == worker_id).all()
        worker = db.query(Worker).filter(Worker.id == worker_id).first()
        if worker and ratings:
            worker.total_ratings = len(ratings)
            worker.rating_avg = round(sum(r.rating for r in ratings) / len(ratings), 2)
            worker.trust_score = calculate_trust_score(worker, db)
            db.flush()
    return r
