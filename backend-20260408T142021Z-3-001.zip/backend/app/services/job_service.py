"""app/services/job_service.py"""
from datetime import datetime
from typing import Optional
from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import or_

from app.models.job import Job, JobApplication
from app.models.worker import Worker
from app.models.employer import Employer
from app.schemas.job import JobCreate, JobUpdate, ApplicationCreate, ApplicationStatusUpdate


# ── Job CRUD ──────────────────────────────────────────────────────────────────

def create_job(employer_id: int, data: JobCreate, db: Session) -> Job:
    job = Job(employer_id=employer_id, **data.model_dump())
    db.add(job)
    db.flush()
    return job


def get_jobs(db: Session, category: Optional[str] = None,
             state: Optional[str] = None, district: Optional[str] = None,
             status: str = "Open", skip: int = 0, limit: int = 20) -> list[Job]:
    q = db.query(Job).filter(Job.status == status)
    if category:
        q = q.filter(Job.category == category)
    if state:
        q = q.filter(Job.state == state)
    if district:
        q = q.filter(Job.district == district)
    return q.order_by(Job.is_urgent.desc(), Job.created_at.desc()).offset(skip).limit(limit).all()


def get_job(job_id: int, db: Session) -> Job:
    job = db.query(Job).filter(Job.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    job.views += 1
    db.flush()
    return job


def update_job(job_id: int, employer_id: int, data: JobUpdate, db: Session) -> Job:
    job = db.query(Job).filter(Job.id == job_id, Job.employer_id == employer_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    for k, v in data.model_dump(exclude_none=True).items():
        setattr(job, k, v)
    db.flush()
    return job


def delete_job(job_id: int, employer_id: int, db: Session):
    job = db.query(Job).filter(Job.id == job_id, Job.employer_id == employer_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    db.delete(job)
    db.flush()


# ── Applications ──────────────────────────────────────────────────────────────

def apply_for_job(job_id: int, worker_id: int,
                  data: ApplicationCreate, db: Session) -> JobApplication:
    job = db.query(Job).filter(Job.id == job_id, Job.status == "Open").first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not open for applications")
    existing = db.query(JobApplication).filter(
        JobApplication.job_id == job_id,
        JobApplication.worker_id == worker_id
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Already applied for this job")
    app = JobApplication(job_id=job_id, worker_id=worker_id, **data.model_dump())
    db.add(app)
    db.flush()
    return app


def update_application_status(app_id: int, employer_id: int,
                               data: ApplicationStatusUpdate, db: Session) -> JobApplication:
    app = db.query(JobApplication).join(Job).filter(
        JobApplication.id == app_id,
        Job.employer_id == employer_id
    ).first()
    if not app:
        raise HTTPException(status_code=404, detail="Application not found")
    app.status = data.status
    app.employer_note = data.employer_note
    if data.status == "Hired":
        app.hired_at = datetime.utcnow()
        app.job.workers_hired += 1
        worker = db.query(Worker).filter(Worker.id == app.worker_id).first()
        if worker:
            worker.jobs_completed += 1
    elif data.status == "Rejected":
        app.rejected_at = datetime.utcnow()
    db.flush()
    return app


def get_worker_applications(worker_id: int, db: Session) -> list[JobApplication]:
    return db.query(JobApplication).filter(
        JobApplication.worker_id == worker_id
    ).order_by(JobApplication.applied_at.desc()).all()


def get_job_applications(job_id: int, employer_id: int, db: Session) -> list[JobApplication]:
    return db.query(JobApplication).join(Job).filter(
        JobApplication.job_id == job_id,
        Job.employer_id == employer_id
    ).all()
