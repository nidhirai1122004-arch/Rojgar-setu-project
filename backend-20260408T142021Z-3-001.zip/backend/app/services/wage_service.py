"""app/services/wage_service.py  –  Wage calculator + govt minimum wage"""
from sqlalchemy.orm import Session
from app.models.gov_wage import GovWage
from app.config import get_settings

settings = get_settings()

SKILL_LEVEL_MAP = {
    "No Experience": "Unskilled",
    "1-2 Years":     "Semi-skilled",
    "3-5 Years":     "Skilled",
    "5+ Years":      "Skilled",
}

DEFAULT_WAGES = {
    "Unskilled":    settings.GOVT_MIN_WAGE_UNSKILLED,
    "Semi-skilled": settings.GOVT_MIN_WAGE_SEMI_SKILLED,
    "Skilled":      settings.GOVT_MIN_WAGE_SKILLED,
}


def get_min_wage(state: str, skill_level: str, db: Session) -> dict:
    level = SKILL_LEVEL_MAP.get(skill_level, "Unskilled")
    gov = db.query(GovWage).filter(
        GovWage.state == state,
        GovWage.skill_category == level
    ).first()
    min_wage = float(gov.wage_per_day) if gov else DEFAULT_WAGES[level]
    return {
        "state": state,
        "skill_level": level,
        "min_wage_per_day": min_wage,
        "source": gov.source if gov else "Default (Central Government)",
    }


def calculate_earnings(daily_wage: float, days: int) -> dict:
    gross  = daily_wage * days
    pf     = round(gross * 0.12, 2)   # 12% PF (if applicable)
    esi    = round(gross * 0.0175, 2) # 1.75% ESI
    net    = round(gross - pf - esi, 2)
    return {
        "daily_wage":   daily_wage,
        "days_worked":  days,
        "gross_earning": gross,
        "pf_deduction": pf,
        "esi_deduction": esi,
        "net_earning":  net,
    }


def is_below_min_wage(offered: float, state: str,
                      skill_level: str, db: Session) -> bool:
    info = get_min_wage(state, skill_level, db)
    return offered < info["min_wage_per_day"]
