"""app/services/matching_service.py  –  Match jobs to workers by skill + location"""
from sqlalchemy.orm import Session
from app.models.worker import Worker
from app.models.job import Job
from app.utils.geo_utils import haversine_km


def match_jobs_for_worker(worker: Worker, db: Session,
                           limit: int = 10) -> list[dict]:
    """Return best-matched open jobs for a worker."""
    jobs = db.query(Job).filter(
        Job.status == "Open",
        Job.state == worker.state,
    ).all()

    scored = []
    for job in jobs:
        score = 0

        # Skill match
        if worker.primary_skill and worker.primary_skill.lower() in (
                job.skills_required or "").lower():
            score += 40
        if worker.skill_category == job.category:
            score += 20

        # District proximity
        if worker.district == job.district:
            score += 30
        elif worker.state == job.state:
            score += 10

        # Wage match
        if (job.daily_wage_min and worker.expected_daily_wage and
                job.daily_wage_min >= float(worker.expected_daily_wage)):
            score += 10

        scored.append({"job": job, "score": score})

    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored[:limit]


def match_workers_for_job(job: Job, db: Session,
                           limit: int = 10) -> list[Worker]:
    """Return best available workers for a job."""
    workers = db.query(Worker).filter(
        Worker.is_available == True,
        Worker.state == job.state,
        Worker.skill_category == job.category,
    ).order_by(Worker.trust_score.desc()).limit(limit).all()
    return workers
