"""app/services/auth_service.py"""
from datetime import datetime
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models.user import User
from app.schemas.auth import RegisterRequest, LoginRequest, OTPVerify
from app.utils.security import hash_password, verify_password, create_access_token
from app.utils.otp import generate_otp, otp_expiry, send_otp_sms


def register_user(data: RegisterRequest, db: Session) -> User:
    if db.query(User).filter(User.mobile == data.mobile).first():
        raise HTTPException(status_code=400, detail="Mobile already registered")
    user = User(
        mobile=data.mobile,
        password_hash=hash_password(data.password),
        role=data.role,
    )
    db.add(user)
    db.flush()
    return user


def login_user(data: LoginRequest, db: Session) -> dict:
    user = db.query(User).filter(User.mobile == data.mobile).first()
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid mobile or password")
    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account disabled")
    user.last_login = datetime.utcnow()
    token = create_access_token({"sub": str(user.id), "role": user.role})
    return {"access_token": token, "token_type": "bearer",
            "role": user.role, "user_id": user.id}


def send_otp(mobile: str, db: Session) -> bool:
    user = db.query(User).filter(User.mobile == mobile).first()
    if not user:
        raise HTTPException(status_code=404, detail="Mobile not registered")
    otp = generate_otp()
    user.otp_code = otp
    user.otp_expires = otp_expiry()
    db.flush()
    return send_otp_sms(mobile, otp)


def verify_otp(data: OTPVerify, db: Session) -> bool:
    user = db.query(User).filter(User.mobile == data.mobile).first()
    if not user or not user.otp_code:
        raise HTTPException(status_code=400, detail="No OTP found for this number")
    if user.otp_expires < datetime.utcnow():
        raise HTTPException(status_code=400, detail="OTP expired")
    if user.otp_code != data.otp:
        raise HTTPException(status_code=400, detail="Incorrect OTP")
    user.is_verified = True
    user.otp_code = None
    user.otp_expires = None
    db.flush()
    return True
