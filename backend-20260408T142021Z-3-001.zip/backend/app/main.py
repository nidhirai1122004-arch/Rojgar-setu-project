"""
app/main.py  –  RozgarSetu FastAPI Application
Railway MySQL + JWT Auth + Full REST API
"""
import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from starlette.middleware.base import BaseHTTPMiddleware

from app.config import get_settings
from app.database import init_db, ping_db
from app.middleware.logging import log_requests

# Routers
from app.routers import (
    auth_routes, worker_routes, employer_routes,
    job_routes, rating_routes, wage_routes, history_routes
)

settings = get_settings()

logging.basicConfig(
    level=logging.DEBUG if settings.DEBUG else logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
)
log = logging.getLogger("rozgar_setu")

# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="RozgarSetu API",
    description=(
        "Labour Linking Platform – connects daily wage workers "
        "with employers across rural India.\n\n"
        "**Railway MySQL** · JWT Auth · Trust Score · Wage Calculator"
    ),
    version=settings.APP_VERSION,
    docs_url="/docs",
    redoc_url="/redoc",
)

# ── Middleware ────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(BaseHTTPMiddleware, dispatch=log_requests)

# ── Startup ───────────────────────────────────────────────────────────────────
@app.on_event("startup")
async def startup():
    log.info("🚀  RozgarSetu API starting …")
    if ping_db():
        log.info("✅  Railway MySQL connected")
        init_db()
    else:
        log.error("❌  Cannot connect to Railway MySQL!")


# ── Routes ────────────────────────────────────────────────────────────────────
API = "/api/v1"
app.include_router(auth_routes.router,     prefix=API)
app.include_router(worker_routes.router,   prefix=API)
app.include_router(employer_routes.router, prefix=API)
app.include_router(job_routes.router,      prefix=API)
app.include_router(rating_routes.router,   prefix=API)
app.include_router(wage_routes.router,     prefix=API)
app.include_router(history_routes.router,  prefix=API)


# ── Health check ──────────────────────────────────────────────────────────────
@app.get("/health", tags=["Health"])
def health():
    db_ok = ping_db()
    return {
        "status": "ok" if db_ok else "degraded",
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "database": "Railway MySQL ✅" if db_ok else "❌ unreachable",
    }


@app.get("/", tags=["Root"])
def root():
    return {
        "message": "Welcome to RozgarSetu API 🏗️",
        "docs": "/docs",
        "health": "/health",
    }
