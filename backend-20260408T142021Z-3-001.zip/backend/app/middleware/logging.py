"""app/middleware/logging.py  –  Request/response logging middleware"""
import time
import logging
from fastapi import Request

log = logging.getLogger("rozgar_setu.http")


async def log_requests(request: Request, call_next):
    start = time.perf_counter()
    response = await call_next(request)
    elapsed = (time.perf_counter() - start) * 1000
    log.info(
        "%s %s  →  %s  (%.1fms)",
        request.method, request.url.path,
        response.status_code, elapsed,
    )
    return response
