"""app/utils/otp.py  –  Generate & (optionally) send OTP via Twilio"""
import random
import string
from datetime import datetime, timedelta
from app.config import get_settings

settings = get_settings()


def generate_otp(length: int = 6) -> str:
    return "".join(random.choices(string.digits, k=length))


def otp_expiry(minutes: int = 10) -> datetime:
    return datetime.utcnow() + timedelta(minutes=minutes)


def send_otp_sms(mobile: str, otp: str) -> bool:
    """
    Send OTP via Twilio. Falls back to console log if Twilio not configured.
    """
    if not settings.TWILIO_ACCOUNT_SID or settings.TWILIO_ACCOUNT_SID == "your_twilio_sid":
        # Dev mode – print to console
        print(f"[DEV OTP] Mobile: {mobile}  OTP: {otp}")
        return True
    try:
        from twilio.rest import Client
        client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
        client.messages.create(
            body=f"Your RozgarSetu OTP is {otp}. Valid for 10 minutes.",
            from_=settings.TWILIO_PHONE_NUMBER,
            to=f"+91{mobile}",
        )
        return True
    except Exception as exc:
        print(f"[OTP ERROR] {exc}")
        return False
