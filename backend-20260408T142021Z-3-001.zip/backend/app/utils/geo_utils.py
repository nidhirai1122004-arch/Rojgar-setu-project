"""app/utils/geo_utils.py  –  Distance calculation helpers"""
from math import radians, sin, cos, sqrt, atan2
from typing import Optional


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Return distance in km between two lat/lon points."""
    R = 6371.0
    phi1, phi2 = radians(lat1), radians(lat2)
    dphi = radians(lat2 - lat1)
    dlam = radians(lon2 - lon1)
    a = sin(dphi / 2) ** 2 + cos(phi1) * cos(phi2) * sin(dlam / 2) ** 2
    return R * 2 * atan2(sqrt(a), sqrt(1 - a))


def workers_within_radius(workers, job_lat: float, job_lon: float,
                           radius_km: float = 50):
    """Filter workers list to those within radius_km of the job location."""
    result = []
    for w in workers:
        if w.latitude and w.longitude:
            dist = haversine_km(float(w.latitude), float(w.longitude),
                                job_lat, job_lon)
            if dist <= radius_km:
                result.append((w, round(dist, 2)))
    result.sort(key=lambda x: x[1])
    return result
