"""app/models/rating.py"""
from datetime import datetime
from sqlalchemy import (Column, Integer, SmallInteger, Text,
                        Boolean, DateTime, ForeignKey)
from sqlalchemy.orm import relationship
from app.database import Base


class Rating(Base):
    __tablename__ = "ratings"

    id                   = Column(Integer, primary_key=True, index=True)
    application_id       = Column(Integer, ForeignKey("job_applications.id",
                                  ondelete="CASCADE"), nullable=False)
    worker_id            = Column(Integer, ForeignKey("workers.id"),   nullable=True)
    employer_id          = Column(Integer, ForeignKey("employers.id"), nullable=True)

    # Who wrote it
    given_by             = Column(Integer, ForeignKey("users.id"), nullable=False)
    rating               = Column(SmallInteger, nullable=False)   # 1–5
    comment              = Column(Text, nullable=True)
    is_visible           = Column(Boolean, default=True)
    created_at           = Column(DateTime, default=datetime.utcnow)

    application = relationship("JobApplication", back_populates="rating")
    worker      = relationship("Worker",   back_populates="ratings",
                               foreign_keys=[worker_id])
    employer    = relationship("Employer", back_populates="ratings",
                               foreign_keys=[employer_id])
