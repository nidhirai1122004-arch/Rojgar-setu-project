"""app/models/work_history.py"""
from datetime import datetime
from sqlalchemy import (Column, Integer, String, Date, DateTime,
                        ForeignKey, DECIMAL, Text, SmallInteger)
from sqlalchemy.orm import relationship
from app.database import Base


class WorkHistory(Base):
    __tablename__ = "work_history"

    id           = Column(Integer, primary_key=True, index=True)
    worker_id    = Column(Integer, ForeignKey("workers.id",   ondelete="CASCADE"),
                          nullable=False, index=True)
    employer_id  = Column(Integer, ForeignKey("employers.id", ondelete="SET NULL"),
                          nullable=True)
    job_id       = Column(Integer, ForeignKey("jobs.id",      ondelete="SET NULL"),
                          nullable=True)

    job_title    = Column(String(200), nullable=False)
    company_name = Column(String(200), nullable=True)
    location     = Column(String(200), nullable=True)
    start_date   = Column(Date, nullable=False)
    end_date     = Column(Date, nullable=True)
    days_worked  = Column(SmallInteger, nullable=True)
    daily_wage   = Column(DECIMAL(8, 2), nullable=True)
    total_earned = Column(DECIMAL(10, 2), nullable=True)
    notes        = Column(Text, nullable=True)
    created_at   = Column(DateTime, default=datetime.utcnow)

    worker   = relationship("Worker",   back_populates="work_history")
    employer = relationship("Employer")
    job      = relationship("Job",      back_populates="work_history")
