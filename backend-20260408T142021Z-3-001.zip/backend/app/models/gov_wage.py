"""app/models/gov_wage.py  –  Government minimum wage table"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, DECIMAL, DateTime, Date
from app.database import Base


class GovWage(Base):
    __tablename__ = "gov_wages"

    id            = Column(Integer, primary_key=True, index=True)
    state         = Column(String(100), nullable=False)
    skill_category = Column(String(100), nullable=False)  # Unskilled / Semi-skilled / Skilled
    wage_per_day  = Column(DECIMAL(8, 2), nullable=False)
    effective_from = Column(Date, nullable=True)
    source        = Column(String(200), nullable=True)    # Ministry / state website
    updated_at    = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
