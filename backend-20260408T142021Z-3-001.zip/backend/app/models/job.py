"""app/models/job.py"""
from datetime import datetime
from sqlalchemy import (Column, Integer, String, Boolean, Enum,
                        DateTime, Date, ForeignKey, DECIMAL, Text)
from sqlalchemy.orm import relationship
from app.database import Base


class Job(Base):
    __tablename__ = "jobs"

    id                   = Column(Integer, primary_key=True, index=True)
    employer_id          = Column(Integer, ForeignKey("employers.id", ondelete="CASCADE"),
                                  nullable=False, index=True)

    title                = Column(String(200), nullable=False)
    description          = Column(Text, nullable=True)
    category             = Column(
        Enum("Construction", "Agriculture", "Housekeeping",
             "Driving", "Factory", "Security", "Other"),
        nullable=False
    )
    job_type             = Column(
        Enum("Full Time", "Part Time", "Seasonal", "Contract"),
        default="Full Time"
    )

    # Location
    state                = Column(String(100), nullable=False)
    district             = Column(String(100), nullable=False)
    village              = Column(String(150), nullable=True)
    pincode              = Column(String(10),  nullable=True)
    latitude             = Column(DECIMAL(10, 7), nullable=True)
    longitude            = Column(DECIMAL(10, 7), nullable=True)

    # Pay
    daily_wage_min       = Column(DECIMAL(8, 2), nullable=True)
    daily_wage_max       = Column(DECIMAL(8, 2), nullable=True)
    wage_type            = Column(Enum("Daily", "Weekly", "Monthly"), default="Daily")

    workers_needed       = Column(Integer, default=1)
    workers_hired        = Column(Integer, default=0)
    experience_needed    = Column(
        Enum("No Experience", "1-2 Years", "3-5 Years", "5+ Years", "Any"),
        default="Any"
    )
    skills_required      = Column(String(500), nullable=True)  # comma-separated

    is_urgent            = Column(Boolean, default=False)
    status               = Column(Enum("Open", "Filled", "Closed", "Draft"), default="Open")

    start_date           = Column(Date, nullable=True)
    end_date             = Column(Date, nullable=True)
    application_deadline = Column(Date, nullable=True)

    views                = Column(Integer, default=0)
    created_at           = Column(DateTime, default=datetime.utcnow)
    updated_at           = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    employer     = relationship("Employer",       back_populates="job_posts")
    applications = relationship("JobApplication", back_populates="job",
                                cascade="all, delete-orphan")
    work_history = relationship("WorkHistory",    back_populates="job")


class JobApplication(Base):
    __tablename__ = "job_applications"

    id            = Column(Integer, primary_key=True, index=True)
    job_id        = Column(Integer, ForeignKey("jobs.id", ondelete="CASCADE"),
                           nullable=False, index=True)
    worker_id     = Column(Integer, ForeignKey("workers.id", ondelete="CASCADE"),
                           nullable=False, index=True)
    cover_note    = Column(Text, nullable=True)
    expected_wage = Column(DECIMAL(8, 2), nullable=True)
    status        = Column(
        Enum("Pending", "Shortlisted", "Hired", "Rejected", "Withdrawn"),
        default="Pending"
    )
    employer_note = Column(Text, nullable=True)
    hired_at      = Column(DateTime, nullable=True)
    rejected_at   = Column(DateTime, nullable=True)
    applied_at    = Column(DateTime, default=datetime.utcnow)
    updated_at    = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    job    = relationship("Job",    back_populates="applications")
    worker = relationship("Worker", back_populates="applications")
    rating = relationship("Rating", back_populates="application", uselist=False)
