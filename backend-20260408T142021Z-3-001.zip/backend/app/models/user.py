"""app/models/user.py"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, Enum, DateTime
from sqlalchemy.orm import relationship
from app.database import Base


class User(Base):
    __tablename__ = "users"

    id             = Column(Integer, primary_key=True, index=True)
    mobile         = Column(String(15), unique=True, nullable=False, index=True)
    email          = Column(String(150), unique=True, nullable=True)
    password_hash  = Column(String(255), nullable=False)
    role           = Column(Enum("worker", "employer", "admin"), default="worker")
    is_active      = Column(Boolean, default=True)
    is_verified    = Column(Boolean, default=False)
    otp_code       = Column(String(6), nullable=True)
    otp_expires    = Column(DateTime, nullable=True)
    last_login     = Column(DateTime, nullable=True)
    created_at     = Column(DateTime, default=datetime.utcnow)
    updated_at     = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    worker_profile   = relationship("Worker",   back_populates="user", uselist=False,
                                    cascade="all, delete-orphan")
    employer_profile = relationship("Employer", back_populates="user", uselist=False,
                                    cascade="all, delete-orphan")
