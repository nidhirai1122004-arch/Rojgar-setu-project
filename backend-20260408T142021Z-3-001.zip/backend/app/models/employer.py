"""app/models/employer.py"""
from datetime import datetime
from sqlalchemy import (Column, Integer, String, Boolean, Enum,
                        DateTime, ForeignKey, DECIMAL, Text)
from sqlalchemy.orm import relationship
from app.database import Base


class Employer(Base):
    __tablename__ = "employers"

    id             = Column(Integer, primary_key=True, index=True)
    user_id        = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"),
                            unique=True, nullable=False)
    company_name   = Column(String(200), nullable=False)
    contact_person = Column(String(150), nullable=False)
    logo           = Column(String(300), nullable=True)

    # Location
    state          = Column(String(100), nullable=False)
    district       = Column(String(100), nullable=False)
    address        = Column(Text, nullable=True)
    pincode        = Column(String(10), nullable=True)
    latitude       = Column(DECIMAL(10, 7), nullable=True)
    longitude      = Column(DECIMAL(10, 7), nullable=True)

    # Business
    business_type  = Column(
        Enum("Construction Company", "Farm / Agriculture", "Factory / Industry",
             "Household / Domestic", "Logistics / Transport",
             "Hotel / Restaurant", "Other"),
        nullable=False
    )
    gst_number     = Column(String(20), nullable=True)
    pan_number     = Column(String(15), nullable=True)
    is_verified    = Column(Boolean, default=False)

    # Stats
    rating_avg     = Column(DECIMAL(3, 2), default=0.00)
    total_ratings  = Column(Integer, default=0)
    workers_hired  = Column(Integer, default=0)
    description    = Column(Text, nullable=True)

    created_at     = Column(DateTime, default=datetime.utcnow)
    updated_at     = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    user      = relationship("User",    back_populates="employer_profile")
    job_posts = relationship("Job",     back_populates="employer",
                             cascade="all, delete-orphan")
    ratings   = relationship("Rating",  back_populates="employer",
                             foreign_keys="Rating.employer_id")
