"""app/models/worker.py"""
from datetime import datetime
from sqlalchemy import (Column, Integer, String, Boolean, Enum,
                        DateTime, Date, ForeignKey, DECIMAL, Text, SmallInteger)
from sqlalchemy.orm import relationship
from app.database import Base


class Worker(Base):
    __tablename__ = "workers"

    id                  = Column(Integer, primary_key=True, index=True)
    user_id             = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"),
                                 unique=True, nullable=False)
    full_name           = Column(String(150), nullable=False)
    age                 = Column(SmallInteger, nullable=True)
    gender              = Column(Enum("Male", "Female", "Other"), nullable=False)
    profile_photo       = Column(String(300), nullable=True)

    # Location
    state               = Column(String(100), nullable=False)
    district            = Column(String(100), nullable=False)
    village             = Column(String(150), nullable=True)
    pincode             = Column(String(10),  nullable=True)
    latitude            = Column(DECIMAL(10, 7), nullable=True)
    longitude           = Column(DECIMAL(10, 7), nullable=True)

    # Skills & work
    primary_skill       = Column(String(100), nullable=False)
    skill_category      = Column(
        Enum("Construction", "Agriculture", "Housekeeping",
             "Driving", "Factory", "Security", "Other"),
        default="Other"
    )
    experience_years    = Column(
        Enum("No Experience", "1-2 Years", "3-5 Years", "5+ Years"),
        default="No Experience"
    )
    expected_daily_wage = Column(DECIMAL(8, 2), nullable=True)
    is_available        = Column(Boolean, default=True)

    # Identity
    aadhaar_number      = Column(String(20), nullable=True)
    aadhaar_verified    = Column(Boolean, default=False)

    # Trust score & stats
    trust_score         = Column(DECIMAL(4, 2), default=50.00)   # 0–100
    rating_avg          = Column(DECIMAL(3, 2), default=0.00)
    total_ratings       = Column(Integer, default=0)
    jobs_completed      = Column(Integer, default=0)
    profile_views       = Column(Integer, default=0)
    bio                 = Column(Text, nullable=True)

    created_at          = Column(DateTime, default=datetime.utcnow)
    updated_at          = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    user         = relationship("User",           back_populates="worker_profile")
    applications = relationship("JobApplication", back_populates="worker")
    ratings      = relationship("Rating",         back_populates="worker",
                                foreign_keys="Rating.worker_id")
    work_history = relationship("WorkHistory",    back_populates="worker")
