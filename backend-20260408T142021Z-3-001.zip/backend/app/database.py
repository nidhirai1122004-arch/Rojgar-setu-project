"""
app/database.py  –  Railway MySQL engine + session factory
"""
import logging
from contextlib import contextmanager

from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.pool import QueuePool
from sqlalchemy.exc import SQLAlchemyError

from app.config import get_settings

log = logging.getLogger("rozgar_setu.db")
settings = get_settings()

# ── Normalise URL (Railway gives plain mysql://) ──────────────────────────────
_url = settings.DATABASE_URL
if _url.startswith("mysql://") and "pymysql" not in _url:
    _url = _url.replace("mysql://", "mysql+pymysql://", 1)

# ── Engine ────────────────────────────────────────────────────────────────────
engine = create_engine(
    _url,
    poolclass=QueuePool,
    pool_size=5,
    max_overflow=10,
    pool_timeout=30,
    pool_recycle=1800,      # avoid Railway idle timeout
    pool_pre_ping=True,     # test connection health before use
    echo=settings.DEBUG,
    connect_args={
        "charset": "utf8mb4",
        "connect_timeout": 10,
    },
)


@event.listens_for(engine, "connect")
def _set_utc(dbapi_conn, _record):
    cur = dbapi_conn.cursor()
    cur.execute("SET time_zone = '+00:00'")
    cur.close()


# ── Session ───────────────────────────────────────────────────────────────────
SessionLocal = sessionmaker(
    bind=engine,
    autocommit=False,
    autoflush=False,
    expire_on_commit=False,
)

Base = declarative_base()


# ── FastAPI dependency ────────────────────────────────────────────────────────
def get_db():
    """Yield a DB session; commit on success, rollback on error."""
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except SQLAlchemyError as exc:
        db.rollback()
        log.error("DB error: %s", exc)
        raise
    finally:
        db.close()


# ── Utility ───────────────────────────────────────────────────────────────────
def init_db():
    """Create all tables (called from main.py on startup)."""
    Base.metadata.create_all(bind=engine)
    log.info("✅  Railway MySQL tables ready.")


def ping_db() -> bool:
    try:
        with engine.connect() as conn:
            return conn.execute(text("SELECT 1")).scalar() == 1
    except Exception as exc:
        log.error("DB ping failed: %s", exc)
        return False
