"""app/schemas/job.py"""
from pydantic import BaseModel
from datetime import datetime, date
from typing import Optional


class JobCreate(BaseModel):
    title: str
    description: Optional[str] = None
    category: str
    job_type: str = "Full Time"
    state: str
    district: str
    village: Optional[str] = None
    pincode: Optional[str] = None
    daily_wage_min: Optional[float] = None
    daily_wage_max: Optional[float] = None
    wage_type: str = "Daily"
    workers_needed: int = 1
    experience_needed: str = "Any"
    skills_required: Optional[str] = None
    is_urgent: bool = False
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    application_deadline: Optional[date] = None


class JobUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    daily_wage_min: Optional[float] = None
    daily_wage_max: Optional[float] = None
    workers_needed: Optional[int] = None
    is_urgent: Optional[bool] = None


class JobOut(BaseModel):
    id: int
    employer_id: int
    title: str
    description: Optional[str]
    category: str
    job_type: str
    state: str
    district: str
    village: Optional[str]
    daily_wage_min: Optional[float]
    daily_wage_max: Optional[float]
    workers_needed: int
    workers_hired: int
    is_urgent: bool
    status: str
    views: int
    created_at: datetime

    model_config = {"from_attributes": True}


class ApplicationCreate(BaseModel):
    cover_note: Optional[str] = None
    expected_wage: Optional[float] = None


class ApplicationOut(BaseModel):
    id: int
    job_id: int
    worker_id: int
    status: str
    cover_note: Optional[str]
    expected_wage: Optional[float]
    applied_at: datetime

    model_config = {"from_attributes": True}


class ApplicationStatusUpdate(BaseModel):
    status: str          # Hired | Rejected | Shortlisted
    employer_note: Optional[str] = None
