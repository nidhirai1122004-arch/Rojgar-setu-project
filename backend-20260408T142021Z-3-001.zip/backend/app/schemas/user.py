"""app/schemas/user.py"""
from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class UserOut(BaseModel):
    id: int
    mobile: str
    email: Optional[str]
    role: str
    is_active: bool
    is_verified: bool
    created_at: datetime

    model_config = {"from_attributes": True}


class WorkerCreate(BaseModel):
    full_name: str
    age: Optional[int] = None
    gender: str
    state: str
    district: str
    village: Optional[str] = None
    pincode: Optional[str] = None
    primary_skill: str
    skill_category: str = "Other"
    experience_years: str = "No Experience"
    expected_daily_wage: Optional[float] = None
    aadhaar_number: Optional[str] = None
    bio: Optional[str] = None


class WorkerUpdate(BaseModel):
    full_name: Optional[str] = None
    age: Optional[int] = None
    state: Optional[str] = None
    district: Optional[str] = None
    village: Optional[str] = None
    primary_skill: Optional[str] = None
    experience_years: Optional[str] = None
    expected_daily_wage: Optional[float] = None
    is_available: Optional[bool] = None
    bio: Optional[str] = None


class WorkerOut(BaseModel):
    id: int
    full_name: str
    gender: str
    state: str
    district: str
    primary_skill: str
    skill_category: str
    experience_years: str
    expected_daily_wage: Optional[float]
    is_available: bool
    trust_score: float
    rating_avg: float
    jobs_completed: int
    profile_views: int
    bio: Optional[str]
    created_at: datetime

    model_config = {"from_attributes": True}


class EmployerCreate(BaseModel):
    company_name: str
    contact_person: str
    state: str
    district: str
    address: Optional[str] = None
    pincode: Optional[str] = None
    business_type: str
    gst_number: Optional[str] = None
    pan_number: Optional[str] = None
    description: Optional[str] = None


class EmployerOut(BaseModel):
    id: int
    company_name: str
    contact_person: str
    state: str
    district: str
    business_type: str
    is_verified: bool
    rating_avg: float
    workers_hired: int
    created_at: datetime

    model_config = {"from_attributes": True}
