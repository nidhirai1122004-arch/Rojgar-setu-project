"""app/routers/rating_routes.py"""
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
from typing import Optional

from app.database import get_db
from app.dependencies import get_current_user
from app.models.user import User
from app.models.worker import Worker
from app.models.employer import Employer
from app.models.rating import Rating
from app.services.trust_score_service import add_rating

router = APIRouter(prefix="/ratings", tags=["Ratings"])


class RatingCreate(BaseModel):
    application_id: int
    worker_id: Optional[int] = None
    employer_id: Optional[int] = None
    rating: int            # 1–5
    comment: Optional[str] = None


@router.post("/", summary="Submit a rating after job completion")
def submit_rating(data: RatingCreate, db: Session = Depends(get_db),
                  current_user: User = Depends(get_current_user)):
    if data.rating < 1 or data.rating > 5:
        from fastapi import HTTPException
        raise HTTPException(400, "Rating must be 1–5")
    r = add_rating(
        application_id=data.application_id,
        worker_id=data.worker_id,
        employer_id=data.employer_id,
        rating_val=data.rating,
        comment=data.comment,
        given_by_user_id=current_user.id,
        db=db,
    )
    return {"message": "Rating submitted", "rating_id": r.id}


@router.get("/worker/{worker_id}", summary="Get all ratings for a worker")
def worker_ratings(worker_id: int, db: Session = Depends(get_db)):
    ratings = db.query(Rating).filter(Rating.worker_id == worker_id,
                                      Rating.is_visible == True).all()
    return ratings


@router.get("/employer/{employer_id}", summary="Get all ratings for an employer")
def employer_ratings(employer_id: int, db: Session = Depends(get_db)):
    ratings = db.query(Rating).filter(Rating.employer_id == employer_id,
                                      Rating.is_visible == True).all()
    return ratings
