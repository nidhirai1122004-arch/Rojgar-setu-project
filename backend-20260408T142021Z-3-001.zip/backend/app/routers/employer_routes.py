"""app/routers/employer_routes.py"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import require_employer, get_current_user
from app.models.user import User
from app.models.employer import Employer
from app.schemas.user import EmployerCreate, EmployerOut

router = APIRouter(prefix="/employers", tags=["Employers"])


@router.post("/profile", response_model=EmployerOut)
def create_profile(data: EmployerCreate, db: Session = Depends(get_db),
                   current_user: User = Depends(require_employer)):
    if db.query(Employer).filter(Employer.user_id == current_user.id).first():
        from fastapi import HTTPException
        raise HTTPException(400, "Employer profile already exists")
    employer = Employer(user_id=current_user.id, **data.model_dump())
    db.add(employer)
    db.flush()
    return employer


@router.get("/profile/me", response_model=EmployerOut)
def get_my_profile(db: Session = Depends(get_db),
                   current_user: User = Depends(require_employer)):
    employer = db.query(Employer).filter(Employer.user_id == current_user.id).first()
    if not employer:
        from fastapi import HTTPException
        raise HTTPException(404, "Profile not found")
    return employer


@router.put("/profile/me", response_model=EmployerOut)
def update_profile(data: EmployerCreate, db: Session = Depends(get_db),
                   current_user: User = Depends(require_employer)):
    employer = db.query(Employer).filter(Employer.user_id == current_user.id).first()
    if not employer:
        from fastapi import HTTPException
        raise HTTPException(404, "Profile not found")
    for k, v in data.model_dump(exclude_none=True).items():
        setattr(employer, k, v)
    db.flush()
    return employer


@router.get("/{employer_id}", response_model=EmployerOut)
def get_employer(employer_id: int, db: Session = Depends(get_db)):
    employer = db.query(Employer).filter(Employer.id == employer_id).first()
    if not employer:
        from fastapi import HTTPException
        raise HTTPException(404, "Employer not found")
    return employer
