"""app/routers/worker_routes.py"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional

from app.database import get_db
from app.dependencies import get_current_user, require_worker
from app.models.user import User
from app.models.worker import Worker
from app.schemas.user import WorkerCreate, WorkerUpdate, WorkerOut
from app.services.trust_score_service import update_worker_trust_score
from app.services.matching_service import match_jobs_for_worker

router = APIRouter(prefix="/workers", tags=["Workers"])


@router.post("/profile", response_model=WorkerOut)
def create_profile(data: WorkerCreate, db: Session = Depends(get_db),
                   current_user: User = Depends(require_worker)):
    if db.query(Worker).filter(Worker.user_id == current_user.id).first():
        from fastapi import HTTPException
        raise HTTPException(400, "Worker profile already exists")
    worker = Worker(user_id=current_user.id, **data.model_dump())
    db.add(worker)
    db.flush()
    update_worker_trust_score(worker.id, db)
    return worker


@router.get("/profile/me", response_model=WorkerOut)
def get_my_profile(db: Session = Depends(get_db),
                   current_user: User = Depends(require_worker)):
    worker = db.query(Worker).filter(Worker.user_id == current_user.id).first()
    if not worker:
        from fastapi import HTTPException
        raise HTTPException(404, "Profile not found. Please create one.")
    return worker


@router.put("/profile/me", response_model=WorkerOut)
def update_profile(data: WorkerUpdate, db: Session = Depends(get_db),
                   current_user: User = Depends(require_worker)):
    worker = db.query(Worker).filter(Worker.user_id == current_user.id).first()
    if not worker:
        from fastapi import HTTPException
        raise HTTPException(404, "Profile not found")
    for k, v in data.model_dump(exclude_none=True).items():
        setattr(worker, k, v)
    db.flush()
    update_worker_trust_score(worker.id, db)
    return worker


@router.get("/{worker_id}", response_model=WorkerOut)
def get_worker(worker_id: int, db: Session = Depends(get_db)):
    worker = db.query(Worker).filter(Worker.id == worker_id).first()
    if not worker:
        from fastapi import HTTPException
        raise HTTPException(404, "Worker not found")
    worker.profile_views += 1
    db.flush()
    return worker


@router.get("/")
def list_workers(
    state: Optional[str] = None,
    skill_category: Optional[str] = None,
    is_available: Optional[bool] = True,
    skip: int = Query(0, ge=0),
    limit: int = Query(20, le=100),
    db: Session = Depends(get_db),
):
    q = db.query(Worker)
    if state:
        q = q.filter(Worker.state == state)
    if skill_category:
        q = q.filter(Worker.skill_category == skill_category)
    if is_available is not None:
        q = q.filter(Worker.is_available == is_available)
    workers = q.order_by(Worker.trust_score.desc()).offset(skip).limit(limit).all()
    return workers


@router.get("/me/recommended-jobs")
def recommended_jobs(db: Session = Depends(get_db),
                     current_user: User = Depends(require_worker)):
    worker = db.query(Worker).filter(Worker.user_id == current_user.id).first()
    if not worker:
        from fastapi import HTTPException
        raise HTTPException(404, "Create your profile first")
    matches = match_jobs_for_worker(worker, db)
    return [{"job_id": m["job"].id, "title": m["job"].title,
             "score": m["score"], "district": m["job"].district,
             "daily_wage_min": m["job"].daily_wage_min} for m in matches]
