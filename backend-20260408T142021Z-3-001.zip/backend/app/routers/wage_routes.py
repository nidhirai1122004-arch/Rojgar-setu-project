"""app/routers/wage_routes.py"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.services.wage_service import get_min_wage, calculate_earnings

router = APIRouter(prefix="/wages", tags=["Wages"])


@router.get("/minimum", summary="Get government minimum wage for state + skill level")
def minimum_wage(
    state: str = Query(..., description="Indian state name"),
    skill_level: str = Query("No Experience",
                             description="No Experience | 1-2 Years | 3-5 Years | 5+ Years"),
    db: Session = Depends(get_db),
):
    return get_min_wage(state, skill_level, db)


@router.get("/calculate", summary="Calculate gross and net earnings")
def wage_calculator(
    daily_wage: float = Query(..., gt=0),
    days_worked: int  = Query(..., gt=0, le=365),
):
    return calculate_earnings(daily_wage, days_worked)
