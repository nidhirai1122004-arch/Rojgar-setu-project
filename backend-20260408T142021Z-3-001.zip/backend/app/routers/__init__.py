from app.routers import (
    auth_routes, worker_routes, employer_routes,
    job_routes, rating_routes, wage_routes, history_routes
)
