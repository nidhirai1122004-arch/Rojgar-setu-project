"""app/routers/history_routes.py"""
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
from datetime import date
from typing import Optional

from app.database import get_db
from app.dependencies import require_worker
from app.models.user import User
from app.models.worker import Worker
from app.models.work_history import WorkHistory

router = APIRouter(prefix="/history", tags=["Work History"])


class HistoryCreate(BaseModel):
    job_title:    str
    company_name: Optional[str] = None
    location:     Optional[str] = None
    start_date:   date
    end_date:     Optional[date] = None
    days_worked:  Optional[int] = None
    daily_wage:   Optional[float] = None
    notes:        Optional[str] = None


@router.get("/me", summary="Get my work history")
def my_history(db: Session = Depends(get_db),
               current_user: User = Depends(require_worker)):
    worker = db.query(Worker).filter(Worker.user_id == current_user.id).first()
    if not worker:
        return []
    return db.query(WorkHistory).filter(
        WorkHistory.worker_id == worker.id
    ).order_by(WorkHistory.start_date.desc()).all()


@router.post("/me", summary="Add work history entry")
def add_history(data: HistoryCreate, db: Session = Depends(get_db),
                current_user: User = Depends(require_worker)):
    worker = db.query(Worker).filter(Worker.user_id == current_user.id).first()
    if not worker:
        from fastapi import HTTPException
        raise HTTPException(404, "Create worker profile first")
    total = None
    if data.daily_wage and data.days_worked:
        total = round(data.daily_wage * data.days_worked, 2)
    entry = WorkHistory(
        worker_id=worker.id,
        total_earned=total,
        **data.model_dump(),
    )
    db.add(entry)
    db.flush()
    return entry
