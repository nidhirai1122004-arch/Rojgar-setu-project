"""app/routers/job_routes.py"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional

from app.database import get_db
from app.dependencies import require_employer, require_worker, get_current_user
from app.models.user import User
from app.models.worker import Worker
from app.models.employer import Employer
from app.schemas.job import (JobCreate, JobUpdate, JobOut,
                              ApplicationCreate, ApplicationOut,
                              ApplicationStatusUpdate)
from app.services import job_service

router = APIRouter(prefix="/jobs", tags=["Jobs"])


@router.get("/", summary="List all open jobs with filters")
def list_jobs(
    category: Optional[str] = None,
    state: Optional[str] = None,
    district: Optional[str] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(20, le=100),
    db: Session = Depends(get_db),
):
    jobs = job_service.get_jobs(db, category, state, district, skip=skip, limit=limit)
    return jobs


@router.post("/", response_model=JobOut, summary="Post a new job (employer only)")
def create_job(data: JobCreate, db: Session = Depends(get_db),
               current_user: User = Depends(require_employer)):
    employer = db.query(Employer).filter(Employer.user_id == current_user.id).first()
    if not employer:
        from fastapi import HTTPException
        raise HTTPException(404, "Create employer profile first")
    return job_service.create_job(employer.id, data, db)


@router.get("/{job_id}", response_model=JobOut)
def get_job(job_id: int, db: Session = Depends(get_db)):
    return job_service.get_job(job_id, db)


@router.put("/{job_id}", response_model=JobOut)
def update_job(job_id: int, data: JobUpdate, db: Session = Depends(get_db),
               current_user: User = Depends(require_employer)):
    employer = db.query(Employer).filter(Employer.user_id == current_user.id).first()
    return job_service.update_job(job_id, employer.id, data, db)


@router.delete("/{job_id}")
def delete_job(job_id: int, db: Session = Depends(get_db),
               current_user: User = Depends(require_employer)):
    employer = db.query(Employer).filter(Employer.user_id == current_user.id).first()
    job_service.delete_job(job_id, employer.id, db)
    return {"message": "Job deleted"}


# ── Applications ──────────────────────────────────────────────────────────────

@router.post("/{job_id}/apply", response_model=ApplicationOut)
def apply(job_id: int, data: ApplicationCreate, db: Session = Depends(get_db),
          current_user: User = Depends(require_worker)):
    worker = db.query(Worker).filter(Worker.user_id == current_user.id).first()
    if not worker:
        from fastapi import HTTPException
        raise HTTPException(404, "Create worker profile first")
    return job_service.apply_for_job(job_id, worker.id, data, db)


@router.get("/{job_id}/applications", summary="Get all applicants for a job")
def get_applicants(job_id: int, db: Session = Depends(get_db),
                   current_user: User = Depends(require_employer)):
    employer = db.query(Employer).filter(Employer.user_id == current_user.id).first()
    return job_service.get_job_applications(job_id, employer.id, db)


@router.put("/applications/{app_id}/status")
def update_status(app_id: int, data: ApplicationStatusUpdate,
                  db: Session = Depends(get_db),
                  current_user: User = Depends(require_employer)):
    employer = db.query(Employer).filter(Employer.user_id == current_user.id).first()
    return job_service.update_application_status(app_id, employer.id, data, db)


@router.get("/my/applications", summary="Worker's own applications")
def my_applications(db: Session = Depends(get_db),
                    current_user: User = Depends(require_worker)):
    worker = db.query(Worker).filter(Worker.user_id == current_user.id).first()
    if not worker:
        return []
    return job_service.get_worker_applications(worker.id, db)
