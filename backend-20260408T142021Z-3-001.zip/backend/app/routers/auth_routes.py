"""app/routers/auth_routes.py"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.auth import RegisterRequest, LoginRequest, OTPRequest, OTPVerify, TokenResponse
from app.services import auth_service

router = APIRouter(prefix="/auth", tags=["Auth"])


@router.post("/register", summary="Register new user (worker or employer)")
def register(data: RegisterRequest, db: Session = Depends(get_db)):
    user = auth_service.register_user(data, db)
    return {"message": "Registration successful", "user_id": user.id, "role": user.role}


@router.post("/login", response_model=TokenResponse, summary="Login with mobile + password")
def login(data: LoginRequest, db: Session = Depends(get_db)):
    return auth_service.login_user(data, db)


@router.post("/otp/send", summary="Send OTP to registered mobile")
def send_otp(data: OTPRequest, db: Session = Depends(get_db)):
    sent = auth_service.send_otp(data.mobile, db)
    return {"message": "OTP sent" if sent else "Failed to send OTP", "sent": sent}


@router.post("/otp/verify", summary="Verify OTP and activate account")
def verify_otp(data: OTPVerify, db: Session = Depends(get_db)):
    auth_service.verify_otp(data, db)
    return {"message": "Mobile verified successfully"}
